var IGPage;
var showhideAnno=true;
var handPan  = true;
var isFWOpen = false;
var floatingWindow;

function InitControls() {

	IGCoreCtl1.object.Result.NotificationFlags = 3;
	IGCoreCtl1.object.AssociateComponent( IGFormatsCtl1.object.ComponentInterface );
	IGCoreCtl1.object.AssociateComponent( IGDisplayCtl1.object.ComponentInterface );
	IGCoreCtl1.object.AssociateComponent( IGProcessingCtl1.object.ComponentInterface );
	IGCoreCtl1.object.AssociateComponent( IGArtCtl1.object.ComponentInterface );// Added By Bandla
	IGCoreCtl1.object.AssociateComponent( IGICCtl1.object.ComponentInterface );
	IGPage = IGCoreCtl1.object.CreatePage();
	IGPageNo = IGCoreCtl1.object.CreatePage();
	IGPageDisplay = IGDisplayCtl1.object.CreatePageDisplay( IGPage );
	IGPageViewCtl1.PageDisplay = IGPageDisplay;
	IGPageViewCtl1.object.Enabled = true;
	IGGUIDlgCtl1.CoreCtl = IGCoreCtl1.object;
	IGGUIDlgCtl1.FormatsCtl = IGFormatsCtl1.object;
	IGGUIDlgCtl1.DisplayCtl = IGDisplayCtl1.object;
	IGPoint = IGCoreCtl1.object.CreateObject(0); // Used for annotations //Added By Bandla
	//IGArt = IGArtCtl1.CreateArtPage(IGPage, IGPageDisplay, IGPageViewCtl1.hWnd ); // Added By Bandla
	IGGUIMagnifyCtl1.object.Initialize( IGCoreCtl1.ComponentInterface, IGDisplayCtl1.ComponentInterface );
	IGGUIMagnifyCtl1.SourceView = IGPageViewCtl1;
	IGGUIMagnifyCtl1.IsPopUp = true;
	IGGUIMagnifyCtl1.zoom = 3;
	IGGUIMagnifyCtl1.PopUpWidth = 100;
	IGGUIMagnifyCtl1.PopUpHeight = 100;
	IGGUIMagnifyCtl1.PopUpShape = 0;	// use a rectangle
	/*for (i = 1; i < 15; i++) {
		IGArtCtl1.ToolBarButtonHide(i, true);
	}
	for (i = 500; i < 516; i++) {
		IGArtCtl1.ToolBarButtonHide(i, true);
	}

	// Enable Loading of Text files
	// var IGFPText = IGFormatsCtl1.Settings.GetFormatRef(41); // 41 -> IG_FORMAT_TXT
	// IGFPText.DetectionEnabled = true;

	IGArtCtl1.ToolBarButtonHide(8, false);
	IGArtCtl1.ToolBarButtonHide(9, false);
	IGArtCtl1.ToolBarButtonHide(10, false);
	IGArtCtl1.ToolBarButtonHide(514, false);
	IGArtCtl1.ToolBarButtonHide(515, false);*/
	
	showTifFile();
}

//C:\Documents and Settings\anil.bolisetti\Desktop\Annotations\Pegasus
function showTifFile(){
	bRes = IGGUIDlgCtl1.ShowLoadFileDlg();
    if (bRes)
    {
	    IGDocument = IGCoreCtl1.object.CreateDocument(0);
		alert(IGGUIDlgCtl1.object.FileName);
		IGFormatsCtl1.object.LoadDocumentFromFile( IGDocument, IGGUIDlgCtl1.object.FileName, 0, 0, -1);
		IGPage = IGDocument.Page(0);
		IGPageDisplay = IGDisplayCtl1.object.CreatePageDisplay(IGPage);
	    IGPageViewCtl1.object.PageDisplay = IGPageDisplay;
	    

	}
	
	var pageSettings = IGPageDisplay.GetPageDisplaySettings();
	
	IGPageDisplay.SetPageDisplaySettings(pageSettings);
	IGPageViewCtl1.PageDisplay = IGPageDisplay;
	IGPageViewCtl1.UpdateView();
}
function addAnnotation(){
	IGArt = IGArtCtl1.CreateArtPage(IGPage, IGPageDisplay, IGPageViewCtl1.hWnd ); 
	
	try {
		alert("Select ART file:");
		ann = IGGUIDlgCtl1.object.ShowLoadFileDlg();
		
		if (ann)
		{
			
			var ioFl = IGFormatsCtl1.object.CreateObject(2);
			
			ioFl.FileName = IGGUIDlgCtl1.object.FileName;
				

			IGArt.LoadAnnotations(ioFl, 0);
			IGArt.SetControlOption(0,0);
			IGPageViewCtl1.UpdateView();
			
			var cmark, nmark;
			/*for(cmark=IGArt.MarkFirst(); cmark>0; ) {

                nmark=IGArt.MarkNext(cmark);
				alert("deleting mark");

                IGArt.MarkDelete(cmark);

                cmark=nmark;

			}*/



			/*var marks = IGArt.MarkCount();
			var markindex = IGArt.MarkFirst();
			var indexArray = new Array(marks);
			indexArray[0]=markindex;
			
			alert(marks);
			for(count = 1; count<marks; count++){
			
				markindex = IGArt.MarkNext(markindex);
				indexArray[count] = markindex;
			}
			
			for(count=0; count<marks; count++){
				alert("count : "+count);
				IGArt.MarkDelete(indexArray[count]);
				
			}*/
			//alert("Mark count : "+IGArt.MarkCount());
			//alert("Mark First : "+ IGArt.MarkFirst());
			//alert("Mark Last : "+ IGArt.MarkNext(IGArt.MarkFirst()));
			
		}
	}catch(e){
		checkForErrors();
	}
	//IGGUIPanCtl1.SetParentImage( IGCoreCtl1.ComponentInterface, IGDisplayCtl1.ComponentInterface,
	//IGPageDisplay, IGPageViewCtl1.hWnd);
	
}
function OnRotateLeft(){
	
	// rotate left
	IGProcessingCtl1.Rotate90k(IGPage, 3);
}
function PrintImage() {
	console.log("PrintImage called");
	alert("PrintImage is called");
	IGGUIDlgCtl1.ShowPrintDocDlg(IGDocument);
	//Display errors if any
}
function OnRotateRight(){

	//rotate right
	IGProcessingCtl1.Rotate90k(IGPage, 1);
}
function showHideTB(){
	IGArtCtl1.ToolBar(IGPageViewCtl1.hWnd,showhideAnno,window.screenLeft,window.screenTop - 70); 
	if (showhideAnno)
		showhideAnno = false;
	else
		showhideAnno = true;
}
function closeTB() {
	if (!showhideAnno)
		showHideTB();
}
function OnChkHandPan() {
	closeTB();
	if (!handPan) {
		handPan = true;
	
		IGGUIPanCtl1.SetParentImage( IGCoreCtl1.ComponentInterface, IGDisplayCtl1.ComponentInterface,
		IGPageDisplay, IGPageViewCtl1.hWnd);
		
	} else {
		handPan = false;
	}
}
function checkForErrors() {
	//Display errors if any
	if (!IGCoreCtl1.Result.IsOk()) {
		var errcount = IGCoreCtl1.Result.ErrorCount; // Get error count
		// Dim rec as IGResultRecord
		var rec = IGCoreCtl1.Result.GetError(errcount - 1); // Get error description
		// Dim errcode as enumIGErrorCodes
		var errcode = rec.ErrCode; // Get error code
		
		alert("ImageGear API Error :" + errcode);
		
		IGCoreCtl1.Result.Clear(); // Clear error stack
		return true;
	} else {
		return false; // No errors found
	}
}

function showHideMagView()
{
	drawRect();
}

var k;
var boundLeft = 800;
var boundRight = 1800;
var boundTop = 1000;
var boundBottom = 1600;

function drawRect()
{
	/*var markProperties = readCookie("ImageGear_mark");
	if (markProperties!=null && markProperties.length>0) {
		boundLeft = markProperties.substring(0, markProperties.indexOf("|"));
		markProperties= markProperties.substring(markProperties.indexOf("|")+1);
		boundRight =markProperties.substring(0, markProperties.indexOf("|"));
		boundTop = markProperties.substring(markProperties.indexOf("|")+1, markProperties.lastIndexOf("|"));
		boundBottom = markProperties.substring(markProperties.lastIndexOf("|")+1);
	}*/
	IGArt = IGArtCtl1.CreateArtPage(IGPage, IGPageDisplay, IGPageViewCtl1.hWnd ); 
	
	IGArt.GlobalAttrBounds.left = boundLeft;
	IGArt.GlobalAttrBounds.Right = boundRight;
	IGArt.GlobalAttrBounds.Top = boundTop;
	IGArt.GlobalAttrBounds.Bottom =boundBottom;
	IGArt.GlobalAttrForeColor.RGB_R= 192;
	IGArt.GlobalAttrForeColor.RGB_G= 192;
	IGArt.GlobalAttrForeColor.RGB_B= 192;
	IGArt.GlobalAttrHighlight= true;
	k = IGArt.MarkCreate(6);
	IGArt.MarkPaint(k);
	
	bRes = IGGUIDlgCtl1.ShowLoadFileDlg();

	if (!isFWOpen) {
		try {
			//floatingWindow = window.open(IGGUIDlgCtl1.object.FileName, 'Magnifier','height=200, width=380, menubar=no, scrollbars=yes, resizable=yes');
			
			floatingWindow= showModelessDialog(IGGUIDlgCtl1.object.FileName,self,"status:false;dialogWidth:300px;dialogHeight:300px;resizable:yes;help:no;");
			isFWOpen = true;
		}
		catch(e) {
			alert(e.description);
		}
	}

	updateImageInMagWindow(boundLeft, boundTop, boundRight, boundBottom);
	
}

var clipRect;
function updateImageInMagWindow(left, top, right, bottom)
{
	clipRect = IGCoreCtl1.CreateObject(1);
	clipRect.Left = left;
	clipRect.Top = top;
	clipRect.Right = right;
	clipRect.Bottom = bottom;
	clipRect.Width = right - left;
	clipRect.Height =  bottom - top;
	try {		
		IGPageDisplay.CopyToClipboard(clipRect);
		floatingWindow.updateImage(); 
	} catch(e) {
		//alert(e.discription);
		IGCoreCtl1.Result.Clear();
	}
}
